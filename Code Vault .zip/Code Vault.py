import tkinter as tk
from tkinter import ttk, messagebox
import base64
import hashlib

class CodeVault:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Code Vault")
        self.window.geometry("600x500")
        
        # Create main frame
        self.main_frame = tk.Frame(self.window)
        self.main_frame.pack(fill="both", expand=True)
        
        # Create tabs
        self.tab_control = ttk.Notebook(self.main_frame)
        self.tab_control.pack(fill="both", expand=True)
        
        self.encrypt_tab = tk.Frame(self.tab_control)
        self.decrypt_tab = tk.Frame(self.tab_control)
        self.hash_tab = tk.Frame(self.tab_control)
        
        self.tab_control.add(self.encrypt_tab, text="Encrypt")
        self.tab_control.add(self.decrypt_tab, text="Decrypt")
        self.tab_control.add(self.hash_tab, text="Hash")
        
        # Encrypt tab
        self.encrypt_label = tk.Label(self.encrypt_tab, text="Enter your message:")
        self.encrypt_label.pack()
        
        self.encrypt_message_entry = tk.Text(self.encrypt_tab, height=10, width=60)
        self.encrypt_message_entry.pack()
        
        self.encrypt_key_label = tk.Label(self.encrypt_tab, text="Enter your secret key:")
        self.encrypt_key_label.pack()
        
        self.encrypt_key_entry = tk.Entry(self.encrypt_tab)
        self.encrypt_key_entry.pack()
        
        self.encrypt_button = tk.Button(self.encrypt_tab, text="Encrypt", command=self.encrypt_message)
        self.encrypt_button.pack()
        
        self.encrypted_message_label = tk.Label(self.encrypt_tab, text="Encrypted message:")
        self.encrypted_message_label.pack()
        
        self.encrypted_message_text = tk.Text(self.encrypt_tab, height=10, width=60)
        self.encrypted_message_text.pack()
        
        # Decrypt tab
        self.decrypt_label = tk.Label(self.decrypt_tab, text="Enter your encrypted message:")
        self.decrypt_label.pack()
        
        self.decrypt_message_entry = tk.Text(self.decrypt_tab, height=10, width=60)
        self.decrypt_message_entry.pack()
        
        self.decrypt_key_label = tk.Label(self.decrypt_tab, text="Enter your secret key:")
        self.decrypt_key_label.pack()
        
        self.decrypt_key_entry = tk.Entry(self.decrypt_tab)
        self.decrypt_key_entry.pack()
        
        self.decrypt_button = tk.Button(self.decrypt_tab, text="Decrypt", command=self.decrypt_message)
        self.decrypt_button.pack()
        
        self.decrypted_message_label = tk.Label(self.decrypt_tab, text="Decrypted message:")
        self.decrypted_message_label.pack()
        
        self.decrypted_message_text = tk.Text(self.decrypt_tab, height=10, width=60)
        self.decrypted_message_text.pack()
        
        # Hash tab
        self.hash_label = tk.Label(self.hash_tab, text="Enter your message to hash:")
        self.hash_label.pack()
        
        self.hash_message_entry = tk.Text(self.hash_tab, height=10, width=60)
        self.hash_message_entry.pack()
        
        self.hash_button = tk.Button(self.hash_tab, text="Hash", command=self.hash_message)
        self.hash_button.pack()
        
        self.hash_message_label = tk.Label(self.hash_tab, text="Hashed message:")
        self.hash_message_label.pack()
        
        self.hash_message_text = tk.Text(self.hash_tab, height=10, width=60)
        self.hash_message_text.pack()
        
        # Base64 tab
        self.base64_tab = tk.Frame(self.tab_control)
        self.tab_control.add(self.base64_tab, text="Base64")
        
        self.base64_label = tk.Label(self.base64_tab, text="Enter your message to encode/decode:")
        self.base64_label.pack()
        
        self.base64_message_entry = tk.Text(self.base64_tab, height=10, width=60)
        self.base64_message_entry.pack()
        
        self.base64_encode_button = tk.Button(self.base64_tab, text="Encode", command=self.base64_encode)
        self.base64_encode_button.pack(side=tk.LEFT)
        
        self.base64_decode_button = tk.Button(self.base64_tab, text="Decode", command=self.base64_decode)
        self.base64_decode_button.pack(side=tk.LEFT)
        
        self.base64_message_label = tk.Label(self.base64_tab, text="Encoded/Decoded message:")
        self.base64_message_label.pack()
        
        self.base64_message_text = tk.Text(self.base64_tab, height=10, width=60)
        self.base64_message_text.pack()
    
    def encrypt_message(self):
        try:
            message = self.encrypt_message_entry.get("1.0", tk.END)
            key = int(self.encrypt_key_entry.get())
            
            encrypted_message = ""
            for char in message:
                encrypted_char = chr((ord(char) + key))
                encrypted_message += encrypted_char
            
            self.encrypted_message_text.delete("1.0", tk.END)
            self.encrypted_message_text.insert("1.0", encrypted_message)
        except ValueError:
            messagebox.showerror("Error", "Invalid key. Please enter a number.")
    
    def decrypt_message(self):
        try:
            message = self.decrypt_message_entry.get("1.0", tk.END)
            key = int(self.decrypt_key_entry.get())
            
            decrypted_message = ""
            for char in message:
                decrypted_char = chr((ord(char) - key))
                decrypted_message += decrypted_char
            
            self.decrypted_message_text.delete("1.0", tk.END)
            self.decrypted_message_text.insert("1.0", decrypted_message)
        except ValueError:
            messagebox.showerror("Error", "Invalid key. Please enter a number.")
    
    def hash_message(self):
        message = self.hash_message_entry.get("1.0", tk.END)
        hashed_message = hashlib.sha256(message.encode()).hexdigest()
        
        self.hash_message_text.delete("1.0", tk.END)
        self.hash_message_text.insert("1.0", hashed_message)
    
    def base64_encode(self):
        message = self.base64_message_entry.get("1.0", tk.END)
        encoded_message = base64.b64encode(message.encode()).decode()
        
        self.base64_message_text.delete("1.0", tk.END)
        self.base64_message_text.insert("1.0", encoded_message)
    
    def base64_decode(self):
        try:
            message = self.base64_message_entry.get("1.0", tk.END)
            decoded_message = base64.b64decode(message.encode()).decode()
            
            self.base64_message_text.delete("1.0", tk.END)
            self.base64_message_text.insert("1.0", decoded_message)
        except Exception as e:
            messagebox.showerror("Error", str(e))
    
    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    app = CodeVault()
    app.run()
 